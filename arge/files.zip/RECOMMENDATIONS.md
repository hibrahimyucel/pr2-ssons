# Auth Service - Geliştirilmesi İçin Öneriler

## 🔒 Güvenlik (Kritik)

### 1. Rate Limiting (Brute-force Koruması)
```typescript
// npm install express-rate-limit
import rateLimit from 'express-rate-limit';

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 dakika
  max: 5, // 5 başarısız deneme
  message: 'Çok fazla login denemesi, lütfen bekleyin'
});

app.post('/api/auth/login', loginLimiter, verifyDeviceIdMiddleware, ...);