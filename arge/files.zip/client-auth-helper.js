/**
 * Web uygulamaları için authentication yardımcı sınıf
 * sales.com, support.com vb. sitelerinde kullanın
 */

class AuthHelper {
  constructor(authServiceUrl = 'http://auth-service.local:3000') {
    this.authServiceUrl = authServiceUrl;
    this.accessTokenKey = 'accessToken';
    this.refreshTokenKey = 'refreshToken';
    this.deviceIdKey = 'deviceId';
    this.initializeDeviceId();
  }

  // Cihaz ID'si oluştur veya mevcut olanı al
  initializeDeviceId() {
    let deviceId = localStorage.getItem(this.deviceIdKey);
    if (!deviceId) {
      deviceId = this.generateDeviceId();
      localStorage.setItem(this.deviceIdKey, deviceId);
    }
    this.deviceId = deviceId;
  }

  // Unique cihaz ID'si oluştur
  generateDeviceId() {
    return 'device_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now();
  }

  // Kayıt yap
  async register(email, password, name) {
    try {
      const response = await fetch(`${this.authServiceUrl}/api/auth/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Device-ID': this.deviceId
        },
        credentials: 'include',
        body: JSON.stringify({ email, password, name })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Kayıt başarısız');
      }

      this.setTokens(data.accessToken, data.refreshToken);
      return { success: true, user: data.user };

    } catch (error) {
      console.error('Register hatası:', error);
      return { success: false, error: error.message };
    }
  }

  // Giriş yap
  async login(email, password) {
    try {
      const response = await fetch(`${this.authServiceUrl}/api/auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Device-ID': this.deviceId
        },
        credentials: 'include',
        body: JSON.stringify({ email, password })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Giriş başarısız');
      }

      this.setTokens(data.accessToken, data.refreshToken);
      return { success: true, user: data.user };

    } catch (error) {
      console.error('Login hatası:', error);
      return { success: false, error: error.message };
    }
  }

  // Oturum bilgisini al
  async getUser() {
    try {
      const accessToken = this.getAccessToken();
      if (!accessToken) {
        return null;
      }

      const response = await fetch(`${this.authServiceUrl}/api/auth/me`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`
        },
        credentials: 'include'
      });

      if (response.status === 401) {
        // Token süresi dolmuş, yenile
        const refreshed = await this.refreshAccessToken();
        if (refreshed) {
          return this.getUser(); // Tekrar dene
        }
        return null;
      }

      if (!response.ok) {
        throw new Error('Kullanıcı bilgisi alınamadı');
      }

      return await response.json();

    } catch (error) {
      console.error('GetUser hatası:', error);
      return null;
    }
  }

  // Access Token'ı yenile
  async refreshAccessToken() {
    try {
      const refreshToken = this.getRefreshToken();
      if (!refreshToken) {
        return false;
      }

      const response = await fetch(`${this.authServiceUrl}/api/auth/refresh`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Device-ID': this.deviceId
        },
        credentials: 'include',
        body: JSON.stringify({ refreshToken })
      });

      const data = await response.json();

      if (!response.ok) {
        this.clearTokens();
        return false;
      }

      this.setAccessToken(data.accessToken);
      return true;

    } catch (error) {
      console.error('Refresh hatası:', error);
      return false;
    }
  }

  // Çıkış yap
  async logout() {
    try {
      const refreshToken = this.getRefreshToken();

      await fetch(`${this.authServiceUrl}/api/auth/logout`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Device-ID': this.deviceId
        },
        credentials: 'include',
        body: JSON.stringify({ refreshToken })
      });

      this.clearTokens();
      return { success: true };

    } catch (error) {
      console.error('Logout hatası:', error);
      this.clearTokens();
      return { success: false, error: error.message };
    }
  }

  // Authorized API call (otomatik token yenileme ile)
  async authenticatedFetch(url, options = {}) {
    let accessToken = this.getAccessToken();

    if (!accessToken) {
      throw new Error('Token bulunamadı');
    }

    // Authorization header'ı ekle
    const headers = {
      ...options.headers,
      'Authorization': `Bearer ${accessToken}`
    };

    let response = await fetch(url, { ...options, headers });

    // 401 ise token yenile ve tekrar dene
    if (response.status === 401) {
      const refreshed = await this.refreshAccessToken();
      if (refreshed) {
        accessToken = this.getAccessToken();
        const newHeaders = {
          ...options.headers,
          'Authorization': `Bearer ${accessToken}`
        };
        response = await fetch(url, { ...options, headers: newHeaders });
      }
    }

    return response;
  }

  // Token'ları kaydet
  setTokens(accessToken, refreshToken) {
    localStorage.setItem(this.accessTokenKey, accessToken);
    localStorage.setItem(this.refreshTokenKey, refreshToken);
  }

  // Access Token'ı kaydet
  setAccessToken(accessToken) {
    localStorage.setItem(this.accessTokenKey, accessToken);
  }

  // Access Token'ı al
  getAccessToken() {
    return localStorage.getItem(this.accessTokenKey);
  }

  // Refresh Token'ı al
  getRefreshToken() {
    return localStorage.getItem(this.refreshTokenKey);
  }

  // Token'ları sil
  clearTokens() {
    localStorage.removeItem(this.accessTokenKey);
    localStorage.removeItem(this.refreshTokenKey);
  }

  // Oturum açmış mı kontrol et
  isLoggedIn() {
    return !!this.getAccessToken();
  }
}

// Dışa aktar
if (typeof module !== 'undefined' && module.exports) {
  module.exports = AuthHelper;
}