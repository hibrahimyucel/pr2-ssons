// Periyodik pool durumu kontrol et
setInterval(() => {
  const stats = (pool as any)._allConnections?.length || 0;
  const free = (pool as any)._freeConnections?.length || 0;
  console.log(`Pool: ${free}/${stats} bağlantı serbest`);
}, 30000); // Her 30 saniyede bir