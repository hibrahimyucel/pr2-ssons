import { Router, Response } from 'express';
import bcrypt from 'bcryptjs';
import { AuthRequest } from '../types';
import { verifyAccessTokenMiddleware, verifyDeviceIdMiddleware } from '../middleware';
import { generateAccessToken, generateRefreshToken, verifyRefreshToken } from '../token';
import {
  createUser,
  findUserByEmail,
  findUserById,
  saveRefreshToken,
  findRefreshToken,
  deleteRefreshToken,
  logSessionHistory
} from '../database';

const router = Router();

// ============ REGISTER ============

/**
 * POST /api/auth/register
 * Yeni kullanıcı kayıt
 */
router.post('/register', verifyDeviceIdMiddleware, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { email, password, name } = req.body;

    if (!email || !password || !name) {
      res.status(400).json({ error: 'Email, şifre ve ad gerekli' });
      return;
    }

    // Şifreyi hash'le
    const hashedPassword = await bcrypt.hash(password, 10);

    // Kullanıcı oluştur
    const userId = await createUser(email, hashedPassword, name);

    // Refresh token'ı kaydet
    const refreshToken = generateRefreshToken(email, userId);
    await saveRefreshToken(userId, refreshToken, req.deviceId!);

    // Session history'e ekle
    await logSessionHistory(
      userId,
      req.deviceId!,
      'REGISTER',
      req.ip,
      req.headers['user-agent']
    );

    const accessToken = generateAccessToken(email, userId);

    res.status(201).json({
      message: 'Kullanıcı başarıyla oluşturuldu',
      accessToken,
      refreshToken,
      user: { id: userId, email, name }
    });

  } catch (error) {
    const message = error instanceof Error ? error.message : 'Kayıt işlemi başarısız';
    console.error('Register hatası:', error);
    res.status(400).json({ error: message });
  }
});

// ============ LOGIN ============

/**
 * POST /api/auth/login
 * Kullanıcı giriş
 */
router.post('/login', verifyDeviceIdMiddleware, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      res.status(400).json({ error: 'Email ve şifre gerekli' });
      return;
    }

    // Kullanıcı bul
    const user = await findUserByEmail(email);
    if (!user) {
      res.status(401).json({ error: 'Email veya şifre hatalı' });
      return;
    }

    // Şifre doğru mu kontrol et
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      res.status(401).json({ error: 'Email veya şifre hatalı' });
      return;
    }

    // Token'ları oluştur
    const accessToken = generateAccessToken(email, user.id);
    const refreshToken = generateRefreshToken(email, user.id);

    // Refresh token'ı kaydet
    await saveRefreshToken(user.id, refreshToken, req.deviceId!);

    // Session history'e ekle
    await logSessionHistory(
      user.id,
      req.deviceId!,
      'LOGIN',
      req.ip,
      req.headers['user-agent']
    );

    res.json({
      message: 'Başarıyla giriş yaptınız',
      accessToken,
      refreshToken,
      user: { id: user.id, email, name: user.name }
    });

  } catch (error) {
    console.error('Login hatası:', error);
    res.status(500).json({ error: 'Giriş işlemi başarısız' });
  }
});

// ============ REFRESH TOKEN ============

/**
 * POST /api/auth/refresh
 * Access Token'ı yenile
 */
router.post('/refresh', verifyDeviceIdMiddleware, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      res.status(400).json({ error: 'Refresh token gerekli' });
      return;
    }

    // Refresh token'ı veritabanında bul
    const tokenRecord = await findRefreshToken(refreshToken, req.deviceId!);
    if (!tokenRecord) {
      res.status(403).json({ error: 'Geçersiz veya süresi dolmuş refresh token' });
      return;
    }

    // Token'ı doğrula
    const decoded = verifyRefreshToken(refreshToken);
    if (!decoded) {
      res.status(403).json({ error: 'Refresh token geçersiz' });
      return;
    }

    // Yeni access token oluştur
    const newAccessToken = generateAccessToken(decoded.email, decoded.userId);

    res.json({
      accessToken: newAccessToken,
      message: 'Access token başarıyla yenilendi'
    });

  } catch (error) {
    console.error('Refresh hatası:', error);
    res.status(500).json({ error: 'Token yenileme işlemi başarısız' });
  }
});

// ============ GET USER ============

/**
 * GET /api/auth/me
 * Mevcut kullanıcı bilgisi
 */
router.get('/me', verifyAccessTokenMiddleware, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Yetkisiz erişim' });
      return;
    }

    const user = await findUserById(req.user.userId);
    if (!user) {
      res.status(404).json({ error: 'Kullanıcı bulunamadı' });
      return;
    }

    res.json(user);

  } catch (error) {
    console.error('Me hatası:', error);
    res.status(500).json({ error: 'Bilgi alma işlemi başarısız' });
  }
});

// ============ LOGOUT ============

/**
 * POST /api/auth/logout
 * Kullanıcı çıkış
 */
router.post('/logout', verifyDeviceIdMiddleware, async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { refreshToken } = req.body;

    if (refreshToken) {
      await deleteRefreshToken(refreshToken, req.deviceId!);
    }

    // Session history'e ekle
    if (req.user) {
      await logSessionHistory(
        req.user.userId,
        req.deviceId!,
        'LOGOUT',
        req.ip,
        req.headers['user-agent']
      );
    }

    res.json({ message: 'Başarıyla çıkış yaptınız' });

  } catch (error) {
    console.error('Logout hatası:', error);
    res.status(500).json({ error: 'Çıkış işlemi başarısız' });
  }
});

// ============ VERIFY TOKEN ============

/**
 * POST /api/auth/verify
 * Token doğrulama (diğer servisler için)
 */
router.post('/verify', async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { accessToken } = req.body;

    if (!accessToken) {
      res.status(400).json({ error: 'Token gerekli' });
      return;
    }

    const decoded = verifyAccessToken(accessToken);
    if (!decoded) {
      res.status(403).json({ valid: false, error: 'Token geçersiz' });
      return;
    }

    res.json({ valid: true, user: decoded });

  } catch (error) {
    console.error('Verify hatası:', error);
    res.status(500).json({ error: 'Token doğrulama başarısız' });
  }
});

export default router;