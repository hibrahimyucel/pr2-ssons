interface AuthResponse {
  success: boolean;
  error?: string;
  user?: any;
  accessToken?: string;
  refreshToken?: string;
  message?: string;
}

interface TokenResponse {
  accessToken: string;
  message?: string;
}

class AuthHelper {
  private authServiceUrl: string;
  private accessTokenKey = 'accessToken';
  private refreshTokenKey = 'refreshToken';
  private deviceIdKey = 'deviceId';
  private deviceId: string;

  constructor(authServiceUrl: string = 'http://localhost:3000') {
    this.authServiceUrl = authServiceUrl;
    this.deviceId = this.getOrCreateDeviceId();
  }

  /**
   * Cihaz ID'si oluştur veya mevcut olanı al
   */
  private getOrCreateDeviceId(): string {
    let deviceId = localStorage.getItem(this.deviceIdKey);
    if (!deviceId) {
      deviceId = this.generateDeviceId();
      localStorage.setItem(this.deviceIdKey, deviceId);
    }
    return deviceId;
  }

  /**
   * Unique cihaz ID'si oluştur
   */
  private generateDeviceId(): string {
    return 'device_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now();
  }

  /**
   * Kayıt yap
   */
  async register(email: string, password: string, name: string): Promise<AuthResponse> {
    try {
      const response = await fetch(`${this.authServiceUrl}/api/auth/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Device-ID': this.deviceId
        },
        credentials: 'include',
        body: JSON.stringify({ email, password, name })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Kayıt başarısız');
      }

      this.setTokens(data.accessToken, data.refreshToken);
      return { success: true, user: data.user };

    } catch (error) {
      const message = error instanceof Error ? error.message : 'Kayıt başarısız';
      console.error('Register hatası:', error);
      return { success: false, error: message };
    }
  }

  /**
   * Giriş yap
   */
  async login(email: string, password: string): Promise<AuthResponse> {
    try {
      const response = await fetch(`${this.authServiceUrl}/api/auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Device-ID': this.deviceId
        },
        credentials: 'include',
        body: JSON.stringify({ email, password })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Giriş başarısız');
      }

      this.setTokens(data.accessToken, data.refreshToken);
      return { success: true, user: data.user };

    } catch (error) {
      const message = error instanceof Error ? error.message : 'Giriş başarısız';
      console.error('Login hatası:', error);
      return { success: false, error: message };
    }
  }

  /**
   * Oturum bilgisini al
   */
  async getUser(): Promise<any | null> {
    try {
      const accessToken = this.getAccessToken();
      if (!accessToken) {
        return null;
      }

      const response = await fetch(`${this.authServiceUrl}/api/auth/me`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`
        },
        credentials: 'include'
      });

      if (response.status === 401) {
        const refreshed = await this.refreshAccessToken();
        if (refreshed) {
          return this.getUser();
        }
        return null;
      }

      if (!response.ok) {
        throw new Error('Kullanıcı bilgisi alınamadı');
      }

      return await response.json();

    } catch (error) {
      console.error('GetUser hatası:', error);
      return null;
    }
  }

  /**
   * Access Token'ı yenile
   */
  async refreshAccessToken(): Promise<boolean> {
    try {
      const refreshToken = this.getRefreshToken();
      if (!refreshToken) {
        return false;
      }

      const response = await fetch(`${this.authServiceUrl}/api/auth/refresh`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Device-ID': this.deviceId
        },
        credentials: 'include',
        body: JSON.stringify({ refreshToken })
      });

      const data: TokenResponse | any = await response.json();

      if (!response.ok) {
        this.clearTokens();
        return false;
      }

      this.setAccessToken(data.accessToken);
      return true;

    } catch (error) {
      console.error('Refresh hatası:', error);
      return false;
    }
  }

  /**
   * Çıkış yap
   */
  async logout(): Promise<AuthResponse> {
    try {
      const refreshToken = this.getRefreshToken();

      await fetch(`${this.authServiceUrl}/api/auth/logout`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Device-ID': this.deviceId
        },
        credentials: 'include',
        body: JSON.stringify({ refreshToken })
      });

      this.clearTokens();
      return { success: true, message: 'Başarıyla çıkış yaptınız' };

    } catch (error) {
      console.error('Logout hatası:', error);
      this.clearTokens();
      const message = error instanceof Error ? error.message : 'Çıkış başarısız';
      return { success: false, error: message };
    }
  }

  /**
   * Authorized API call (otomatik token yenileme ile)
   */
  async authenticatedFetch(url: string, options: RequestInit = {}): Promise<Response> {
    let accessToken = this.getAccessToken();

    if (!accessToken) {
      throw new Error('Token bulunamadı');
    }

    const headers = {
      ...options.headers,
      'Authorization': `Bearer ${accessToken}`
    };

    let response = await fetch(url, { ...options, headers });

    if (response.status === 401) {
      const refreshed = await this.refreshAccessToken();
      if (refreshed) {
        accessToken = this.getAccessToken()!;
        const newHeaders = {
          ...options.headers,
          'Authorization': `Bearer ${accessToken}`
        };
        response = await fetch(url, { ...options, headers: newHeaders });
      }
    }

    return response;
  }

  /**
   * Token'ları kaydet
   */
  private setTokens(accessToken: string, refreshToken: string): void {
    localStorage.setItem(this.accessTokenKey, accessToken);
    localStorage.setItem(this.refreshTokenKey, refreshToken);
  }

  /**
   * Access Token'ı kaydet
   */
  private setAccessToken(accessToken: string): void {
    localStorage.setItem(this.accessTokenKey, accessToken);
  }

  /**
   * Access Token'ı al
   */
  getAccessToken(): string | null {
    return localStorage.getItem(this.accessTokenKey);
  }

  /**
   * Refresh Token'ı al
   */
  getRefreshToken(): string | null {
    return localStorage.getItem(this.refreshTokenKey);
  }

  /**
   * Token'ları sil
   */
  clearTokens(): void {
    localStorage.removeItem(this.accessTokenKey);
    localStorage.removeItem(this.refreshTokenKey);
  }

  /**
   * Oturum açmış mı kontrol et
   */
  isLoggedIn(): boolean {
    return !!this.getAccessToken();
  }
}

export default AuthHelper;