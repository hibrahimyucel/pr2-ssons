import { generateAccessToken, verifyAccessToken } from './token';

describe('Token Utils', () => {
  it('should generate valid access token', () => {
    const token = generateAccessToken('test@example.com', 1);
    expect(token).toBeDefined();
  });

  it('should verify valid token', () => {
    const token = generateAccessToken('test@example.com', 1);
    const decoded = verifyAccessToken(token);
    expect(decoded?.email).toBe('test@example.com');
  });

  it('should reject invalid token', () => {
    const result = verifyAccessToken('invalid_token');
    expect(result).toBeNull();
  });
});