const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const mysql = require('mysql2/promise');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(express.json());

// CORS yapılandırması - birden fazla domain için
const allowedDomains = ['sales.com', 'support.com', 'localhost:3000', 'localhost:3001'];
app.use(cors({
  origin: allowedDomains,
  credentials: true
}));

// MariaDB connection pool
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME || 'auth_service',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// JWT secrets
const ACCESS_TOKEN_SECRET = process.env.ACCESS_TOKEN_SECRET;
const REFRESH_TOKEN_SECRET = process.env.REFRESH_TOKEN_SECRET;

// Access Token üretimi (15 dakika)
function generateAccessToken(email, userId) {
  return jwt.sign(
    { email, userId, type: 'access' },
    ACCESS_TOKEN_SECRET,
    { expiresIn: '15m' }
  );
}

// Refresh Token üretimi (7 gün)
function generateRefreshToken(email, userId) {
  return jwt.sign(
    { email, userId, type: 'refresh' },
    REFRESH_TOKEN_SECRET,
    { expiresIn: '7d' }
  );
}

// Middleware: Access Token doğrulama
function verifyAccessToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Token gerekli' });
  }

  jwt.verify(token, ACCESS_TOKEN_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Token geçersiz veya süresi doldu' });
    }
    req.user = user;
    next();
  });
}

// Middleware: Cihaz kimliği doğrulama
function verifyDeviceId(req, res, next) {
  const deviceId = req.headers['x-device-id'];
  if (!deviceId) {
    return res.status(400).json({ error: 'Device ID gerekli' });
  }
  req.deviceId = deviceId;
  next();
}

// Kayıt (Register)
app.post('/api/auth/register', verifyDeviceId, async (req, res) => {
  try {
    const { email, password, name } = req.body;

    if (!email || !password || !name) {
      return res.status(400).json({ error: 'Email, şifre ve ad gerekli' });
    }

    const connection = await pool.getConnection();

    // Email zaten var mı kontrol et
    const [existingUser] = await connection.query(
      'SELECT id FROM users WHERE email = ?',
      [email]
    );

    if (existingUser.length > 0) {
      connection.release();
      return res.status(409).json({ error: 'Email zaten kullanımda' });
    }

    // Şifreyi hash'le
    const hashedPassword = await bcrypt.hash(password, 10);

    // Kullanıcı oluştur
    const [result] = await connection.query(
      'INSERT INTO users (email, password, name, created_at) VALUES (?, ?, ?, NOW())',
      [email, hashedPassword, name]
    );

    const userId = result.insertId;

    // Refresh token'ı veritabanına kaydet
    const refreshToken = generateRefreshToken(email, userId);
    await connection.query(
      'INSERT INTO refresh_tokens (user_id, token, device_id, expires_at) VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL 7 DAY))',
      [userId, refreshToken, req.deviceId]
    );

    connection.release();

    const accessToken = generateAccessToken(email, userId);

    res.status(201).json({
      message: 'Kullanıcı başarıyla oluşturuldu',
      accessToken,
      refreshToken,
      user: { id: userId, email, name }
    });

  } catch (error) {
    console.error('Register hatası:', error);
    res.status(500).json({ error: 'Kayıt işlemi başarısız' });
  }
});

// Giriş (Login)
app.post('/api/auth/login', verifyDeviceId, async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email ve şifre gerekli' });
    }

    const connection = await pool.getConnection();

    // Kullanıcı bul
    const [users] = await connection.query(
      'SELECT id, password, name FROM users WHERE email = ?',
      [email]
    );

    if (users.length === 0) {
      connection.release();
      return res.status(401).json({ error: 'Email veya şifre hatalı' });
    }

    const user = users[0];

    // Şifre doğru mu kontrol et
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      connection.release();
      return res.status(401).json({ error: 'Email veya şifre hatalı' });
    }

    // Eski refresh token'ları temizle (isteğe bağlı)
    // await connection.query(
    //   'DELETE FROM refresh_tokens WHERE user_id = ? AND device_id = ? AND expires_at < NOW()',
    //   [user.id, req.deviceId]
    // );

    // Yeni token'ları oluştur
    const accessToken = generateAccessToken(email, user.id);
    const refreshToken = generateRefreshToken(email, user.id);

    // Refresh token'ı veritabanına kaydet
    await connection.query(
      'INSERT INTO refresh_tokens (user_id, token, device_id, expires_at) VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL 7 DAY))',
      [user.id, refreshToken, req.deviceId]
    );

    connection.release();

    res.json({
      message: 'Başarıyla giriş yaptınız',
      accessToken,
      refreshToken,
      user: { id: user.id, email, name: user.name }
    });

  } catch (error) {
    console.error('Login hatası:', error);
    res.status(500).json({ error: 'Giriş işlemi başarısız' });
  }
});

// Refresh Token (Access Token'ı yenile)
app.post('/api/auth/refresh', verifyDeviceId, async (req, res) => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      return res.status(400).json({ error: 'Refresh token gerekli' });
    }

    const connection = await pool.getConnection();

    // Refresh token'ı veritabanında bul
    const [tokens] = await connection.query(
      'SELECT user_id, token FROM refresh_tokens WHERE token = ? AND device_id = ? AND expires_at > NOW()',
      [refreshToken, req.deviceId]
    );

    connection.release();

    if (tokens.length === 0) {
      return res.status(403).json({ error: 'Geçersiz veya süresi dolmuş refresh token' });
    }

    // Token'ı doğrula
    jwt.verify(refreshToken, REFRESH_TOKEN_SECRET, (err, user) => {
      if (err) {
        return res.status(403).json({ error: 'Refresh token geçersiz' });
      }

      const newAccessToken = generateAccessToken(user.email, user.userId);

      res.json({
        accessToken: newAccessToken,
        message: 'Access token başarıyla yenilendi'
      });
    });

  } catch (error) {
    console.error('Refresh hatası:', error);
    res.status(500).json({ error: 'Token yenileme işlemi başarısız' });
  }
});

// Oturum kontrolü (Check Auth)
app.get('/api/auth/me', verifyAccessToken, async (req, res) => {
  try {
    const connection = await pool.getConnection();

    const [users] = await connection.query(
      'SELECT id, email, name FROM users WHERE id = ?',
      [req.user.userId]
    );

    connection.release();

    if (users.length === 0) {
      return res.status(404).json({ error: 'Kullanıcı bulunamadı' });
    }

    res.json(users[0]);

  } catch (error) {
    console.error('Me hatası:', error);
    res.status(500).json({ error: 'Bilgi alma işlemi başarısız' });
  }
});

// Çıkış (Logout)
app.post('/api/auth/logout', verifyDeviceId, async (req, res) => {
  try {
    const { refreshToken } = req.body;

    if (refreshToken) {
      const connection = await pool.getConnection();
      await connection.query(
        'DELETE FROM refresh_tokens WHERE token = ? AND device_id = ?',
        [refreshToken, req.deviceId]
      );
      connection.release();
    }

    res.json({ message: 'Başarıyla çıkış yaptınız' });

  } catch (error) {
    console.error('Logout hatası:', error);
    res.status(500).json({ error: 'Çıkış işlemi başarısız' });
  }
});

// Token doğrulama (diğer servisler için)
app.post('/api/auth/verify', async (req, res) => {
  try {
    const { accessToken } = req.body;

    if (!accessToken) {
      return res.status(400).json({ error: 'Token gerekli' });
    }

    jwt.verify(accessToken, ACCESS_TOKEN_SECRET, (err, user) => {
      if (err) {
        return res.status(403).json({ valid: false, error: 'Token geçersiz' });
      }
      res.json({ valid: true, user });
    });

  } catch (error) {
    console.error('Verify hatası:', error);
    res.status(500).json({ error: 'Token doğrulama başarısız' });
  }
});

// Server başlat
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Auth Service ${PORT} portunda çalışıyor`);
});