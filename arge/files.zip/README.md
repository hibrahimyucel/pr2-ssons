# Auth Service - TypeScript

Birden fazla web uygulaması için merkezi **Single Sign-On (SSO)** çözümü sağlayan **authentication micro-service**.

> **sales.com**, **support.com** gibi farklı domain'lerdeki uygulamalarda kullanıcılar aynı cihazdan bir kez giriş yapınca tüm uygulamalarda otomatik olarak oturum açmış olurlar.

---

## 📋 İçindekiler

- [Proje Amacı](#proje-amacı)
- [Özellikler](#özellikler)
- [Teknoloji Stack](#teknoloji-stack)
- [Sistem Gereksinimleri](#sistem-gereksinimleri)
- [Kurulum](#kurulum)
- [Kullanım](#kullanım)
- [API Endpoints](#api-endpoints)
- [Veritabanı Şeması](#veritabanı-şeması)
- [Klasör Yapısı](#klasör-yapısı)
- [Güvenlik](#güvenlik)
- [Production Hazırlığı](#production-hazırlığı)
- [Sorun Giderme](#sorun-giderme)

---

## 🎯 Proje Amacı

Geleneksel single-application authentication sistemlerinin aksine, bu proje **birden fazla web uygulamasının aynı merkezi servisten yararlanmasını** sağlar.

### Kullanım Senaryosu
